// C:\Users\USER\bookfete\frontend\src\components\book\chapters\QuestionsSectionLuxe.js
import React, { useEffect } from 'react';
import Tooltip from '../../ui/Tooltip';
import '../BookLuxe.css';

const QuestionsSectionLuxe = ({ 
  questions, 
  onGenerate, 
  generating, 
  chapterTitle, 
  eventType, 
  style,
  isOrganizer,
  onEdit,
  questionsValidated,
  onValidate,
  readOnly
}) => {
  
  // Régénérer automatiquement quand le titre change
  useEffect(() => {
    if (chapterTitle && !questionsValidated) {
      console.log('🔄 Génération auto pour:', chapterTitle);
      onGenerate();
    }
  }, [chapterTitle]);

  // Si les questions sont validées, on les affiche en lecture seule
  const displayQuestions = questionsValidated ? questions : (questions || []);

  return (
    <div className={`questions-section ${questionsValidated ? 'validated' : ''}`}>
      <div className="questions-header">
        <h3>
          {questionsValidated ? '✅ Questions validées' : '✨ QUESTIONS SUGGÉRÉES PAR L\'IA'}
        </h3>
        <Tooltip text="Ces questions seront envoyées aux invités pour les guider dans leur contribution">
          <span style={{ color: 'var(--gold)', cursor: 'help' }}>ⓘ</span>
        </Tooltip>
      </div>
      
      <ul className="questions-list">
        {displayQuestions && displayQuestions.length > 0 ? (
          displayQuestions.map((q, idx) => (
            <li key={idx}>{q}</li>
          ))
        ) : (
          <li style={{ fontStyle: 'italic' }}>Aucune question pour l'instant</li>
        )}
      </ul>

      {/* Message d'information */}
      <p className="questions-info">
        Ces questions seront envoyées aux invités pour les guider dans leur contribution.
      </p>

      {/* Boutons visibles uniquement pour l'organisateur */}
      {isOrganizer && !readOnly && (
        <div className="questions-actions">
          {!questionsValidated && (
            <>
              <button
                onClick={() => {
                  console.log('🟢 Clic sur Regénérer');
                  onGenerate();
                }}
                disabled={generating}
                className="btn btn-outline"
                style={{ flex: 1 }}
              >
                {generating ? '✨ Génération...' : '🎲 Regénérer'}
              </button>
              
              <button
                onClick={() => {
                  console.log('🟢 Clic sur Modifier/Ajouter');
                  onEdit();
                }}
                className="btn btn-outline"
                style={{ flex: 1 }}
              >
                ✏️ Modifier/Ajouter
              </button>

              <button
                onClick={() => {
                  console.log('🟢 Clic sur Valider');
                  onValidate();
                }}
                className="btn btn-primary"
                style={{ flex: 1 }}
              >
                ✅ Valider
              </button>
            </>
          )}
          
          {questionsValidated && (
            <div className="validated-message">
              ✓ Questions validées - elles seront envoyées aux invités
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default QuestionsSectionLuxe;