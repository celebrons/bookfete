// C:\Users\USER\bookfete\frontend\src\components\book\chapters\ChapterWorkflowLuxe.js
import React, { useState, useEffect } from 'react';
import QuestionsSectionLuxe from './QuestionsSectionLuxe';
import ContributionFormLuxe from './ContributionFormLuxe';
import ChapterInvitationsLuxe from './ChapterInvitationsLuxe';
import '../BookLuxe.css';

const ChapterWorkflowLuxe = ({
  chapter,
  chaptersCount,
  onGenerateQuestions,
  generatingQuestions,
  contributionText,
  setContributionText,
  photos,
  photoPreviews,
  onPhotoChange,
  onRemovePhoto,
  onSubmitContribution,
  submitting,
  onLoadContributions,
  onCopyInviteLink,
  inviteSuccess,
  userEmail,
  user,
  book,
  onEditQuestions,
  onValidateQuestions,
  questionsValidated,
  hasContributed,
  onEditContribution,
  invitations,
  isFinalized,
  onFinalizeContribution,
  existingContribution
}) => {
  
  // État pour suivre l'étape courante
  const [currentStep, setCurrentStep] = useState(1);
  const [expandedSections, setExpandedSections] = useState({
    step1: true,
    step2: false,
    step3: false,
    step4: false
  });

  // Vérifier les étapes accomplies
  useEffect(() => {
    // Étape 1 : questions validées
    if (questionsValidated) {
      setExpandedSections(prev => ({ ...prev, step1: false, step2: true }));
      setCurrentStep(2);
    }

    // Étape 2 : organisateur a un brouillon
    if (hasContributed && !isFinalized) {
      setCurrentStep(2);
    }

    // Étape 2 : organisateur a finalisé sa contribution
    if (isFinalized) {
      setExpandedSections(prev => ({ ...prev, step2: false, step3: true }));
      setCurrentStep(3);
    }
  }, [questionsValidated, hasContributed, isFinalized]);

  const toggleSection = (step) => {
    if (step === 1 && questionsValidated) {
      setExpandedSections(prev => ({ ...prev, step1: !prev.step1 }));
    } else if (step === 2 && hasContributed && !isFinalized) {
      setExpandedSections(prev => ({ ...prev, step2: !prev.step2 }));
    } else if (step === 3) {
      setExpandedSections(prev => ({ ...prev, step3: !prev.step3 }));
    }
  };

  const isOrganizer = user && book && user.id === book.owner_id;

  return (
    <div className="workflow-container" style={{ marginBottom: 'var(--space-xl)' }}>
      
      {/* ÉTAPE 1 : Génération et validation des questions */}
      <div className={`workflow-step ${currentStep === 1 ? 'current' : ''} ${questionsValidated ? 'completed' : ''}`}>
        <div 
          className={`workflow-header ${expandedSections.step1 ? 'expanded' : ''}`}
          onClick={() => questionsValidated && toggleSection(1)}
          style={{ cursor: questionsValidated ? 'pointer' : 'default' }}
        >
          <div className="workflow-step-number">
            {questionsValidated ? '✓' : '1'}
          </div>
          <div className="workflow-step-title">
            Étape 1 : Questions pour les contributeurs
          </div>
          <div className="workflow-step-status">
            {questionsValidated ? '✅ Validées' : (currentStep === 1 ? '⚙️ En cours' : '⏳ À faire')}
          </div>
        </div>
        
        {expandedSections.step1 && (
          <div className="workflow-content">
            <QuestionsSectionLuxe
              questions={chapter.questions_ia}
              onGenerate={() => onGenerateQuestions(chapter)}
              generating={generatingQuestions}
              chapterTitle={chapter.title}
              eventType={chapter.event_type}
              style={chapter.style_narratif}
              isOrganizer={isOrganizer}
              onEdit={onEditQuestions}
              questionsValidated={questionsValidated}
              onValidate={onValidateQuestions}
              readOnly={questionsValidated}
            />
          </div>
        )}
      </div>

      {/* ÉTAPE 2 : Contribution de l'organisateur */}
      <div className={`workflow-step ${currentStep === 2 ? 'current' : ''} ${isFinalized ? 'completed' : ''} ${!questionsValidated ? 'locked' : ''}`}>
        <div 
          className={`workflow-header ${expandedSections.step2 ? 'expanded' : ''}`}
          onClick={() => questionsValidated && hasContributed && !isFinalized && toggleSection(2)}
          style={{ cursor: (questionsValidated && hasContributed && !isFinalized) ? 'pointer' : 'default' }}
        >
          <div className="workflow-step-number">
            {isFinalized ? '✓' : (hasContributed ? '📝' : '2')}
          </div>
          <div className="workflow-step-title">
            Étape 2 : Votre contribution personnelle
          </div>
          <div className="workflow-step-status">
            {!questionsValidated ? '🔒 Attend étape 1' : 
             isFinalized ? '✅ Finalisée' : 
             hasContributed ? '📝 Brouillon' : 
             (currentStep === 2 ? '⚙️ En cours' : '⏳ À faire')}
          </div>
        </div>
        
        {expandedSections.step2 && !isFinalized && (
          <div className="workflow-content">
            <ContributionFormLuxe
              contributionText={contributionText}
              setContributionText={setContributionText}
              photos={photos}
              photoPreviews={photoPreviews}
              onPhotoChange={onPhotoChange}
              onRemovePhoto={onRemovePhoto}
              onSubmit={onSubmitContribution}
              submitting={submitting}
              hasContributed={hasContributed}
              onEdit={onEditContribution}
              existingPhotos={existingContribution?.photo_urls || []}
              chapterTitle={chapter.title}
              isFinalized={isFinalized}
              onFinalize={onFinalizeContribution}
              contributionId={existingContribution?.id}
            />
          </div>
        )}

        {expandedSections.step2 && isFinalized && (
          <div className="workflow-content">
            <div className="finalized-message">
              <div className="finalized-icon">✅</div>
              <h3 className="finalized-title">Contribution finalisée</h3>
              <p className="finalized-text">Vous ne pouvez plus la modifier.</p>
            </div>
          </div>
        )}
      </div>

      {/* ÉTAPE 3 : Invitations aux contributeurs */}
      <div className={`workflow-step ${currentStep === 3 ? 'current' : ''} ${invitations?.length > 0 ? 'completed' : ''} ${!hasContributed ? 'locked' : ''}`}>
        <div 
          className={`workflow-header ${expandedSections.step3 ? 'expanded' : ''}`}
          onClick={() => hasContributed && toggleSection(3)}
          style={{ cursor: hasContributed ? 'pointer' : 'default' }}
        >
          <div className="workflow-step-number">
            {invitations?.length > 0 ? '✓' : '3'}
          </div>
          <div className="workflow-step-title">
            Étape 3 : Inviter des contributeurs
          </div>
          <div className="workflow-step-status">
            {!hasContributed ? '🔒 Attend étape 2' : (invitations?.length > 0 ? `${invitations.length} invité(s)` : '⏳ À faire')}
          </div>
        </div>
        
        {expandedSections.step3 && (
          <div className="workflow-content">
            {/* Bouton Voir/Modérer les contributions */}
            <button
              onClick={() => onLoadContributions(chapter.id)}
              className="btn btn-outline"
              style={{ width: '100%', marginBottom: 'var(--space-lg)' }}
            >
              <span>👁️</span> Voir et modérer les contributions
            </button>
            
            <ChapterInvitationsLuxe 
              chapterId={chapter.id}
            />
          </div>
        )}
      </div>

      {/* ÉTAPE 4 : Validation et clôture */}
      <div className="workflow-step">
        <div className="workflow-header">
          <div className="workflow-step-number">4</div>
          <div className="workflow-step-title">
            Étape 4 : Valider et clôturer le chapitre
          </div>
          <div className="workflow-step-status">
            <button 
              className="btn btn-outline" 
              style={{ fontSize: '12px' }}
              onClick={() => alert('Fonction à venir')}
            >
              Clôturer
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChapterWorkflowLuxe;