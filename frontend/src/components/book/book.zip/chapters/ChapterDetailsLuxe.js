// C:\Users\USER\bookfete\frontend\src\components\book\chapters\ChapterDetailsLuxe.js
import React, { useState, useEffect } from 'react';
import QuestionsSectionLuxe from './QuestionsSectionLuxe';
import ContributionFormLuxe from './ContributionFormLuxe';
import ChapterInvitationsLuxe from './ChapterInvitationsLuxe';
import ChapterWorkflowLuxe from './ChapterWorkflowLuxe';
import { supabase } from '../../../services/supabaseClient';
import '../BookLuxe.css';

const ChapterDetailsLuxe = ({
  chapter,
  chaptersCount,
  onGenerateQuestions,
  generatingQuestions,
  contributionText,
  setContributionText,
  photos,
  photoPreviews,
  onPhotoChange,
  onRemovePhoto,
  onSubmitContribution,
  submitting,
  onLoadContributions,
  onCopyInviteLink,
  inviteSuccess,
  userEmail,
  user,
  book,
  onEditQuestions,
  onValidateQuestions,
  questionsValidated,
  hasContributed,
  onEditContribution,
  invitations,
  isFinalized,
  onFinalizeContribution,
  existingContribution
}) => {
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (chapter?.id && userEmail) {
      setLoading(false);
    }
  }, [chapter?.id, userEmail]);

  if (loading) {
    return (
      <div style={{ textAlign: 'center', padding: 'var(--space-xxl)' }}>
        <div className="spinner" style={{
          border: '2px solid var(--mist)',
          borderTop: '2px solid var(--gold)',
          borderRadius: '50%',
          width: '40px',
          height: '40px',
          animation: 'spin 1s linear infinite',
          margin: '0 auto var(--space-md)'
        }} />
        <p className="body-text" style={{ color: 'var(--text-light)' }}>
          Chargement...
        </p>
      </div>
    );
  }

  return (
    <>
      <h2 className="chapter-title-main">{chapter.title}</h2>
      
      <p className="chapter-subtitle">
        ALBUM PRESTIGE • {chaptersCount} CHAPITRES
      </p>

      <ChapterWorkflowLuxe
        chapter={chapter}
        chaptersCount={chaptersCount}
        onGenerateQuestions={onGenerateQuestions}
        generatingQuestions={generatingQuestions}
        contributionText={contributionText}
        setContributionText={setContributionText}
        photos={photos}
        photoPreviews={photoPreviews}
        onPhotoChange={onPhotoChange}
        onRemovePhoto={onRemovePhoto}
        onSubmitContribution={onSubmitContribution}
        submitting={submitting}
        onLoadContributions={onLoadContributions}
        onCopyInviteLink={onCopyInviteLink}
        inviteSuccess={inviteSuccess}
        userEmail={userEmail}
        user={user}
        book={book}
        onEditQuestions={onEditQuestions}
        onValidateQuestions={onValidateQuestions}
        questionsValidated={questionsValidated}
        hasContributed={hasContributed}
        onEditContribution={onEditContribution}
        invitations={invitations}
        isFinalized={isFinalized}
        onFinalizeContribution={onFinalizeContribution}
        existingContribution={existingContribution}
      />
    </>
  );
};

export default ChapterDetailsLuxe;